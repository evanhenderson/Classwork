#include <iostream>
using namespace std;
int main()
{
	for (int count= 1; count < 50; count += 2)
		cout << count << endl;
	return 0;
}