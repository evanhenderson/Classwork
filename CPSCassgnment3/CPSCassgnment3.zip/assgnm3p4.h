#include <iostream>
using namespace std;
int main()
{
	double cpm, total;
	cpm = 3.6
	for (int t = 5; t <= 30; t += 5)
	{
		total = cpm * t;
		cout << total << endl;
	}
	return 0;
}